<template>
<div class="box">
    <div class="inbox">
  
       

    </div>
</div>
</template>
<script>
import Bus from "@/bus.js";
export default {
 name:"MlList2",
  components:{
  
  },
  data(){
return{
   
}
  },
  mounted(){
   
  },
  methods: {
     
  }
};
</script>
<style lang="scss" scoped>
.box {
 /*  width: 1128px; */
 /*  height: 595px; */
  /* height: 61.4035087719vh; */
 /*  overflow: auto; */
}
.inbox {
 /*  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  justify-content: flex-start;
  align-items: center; */
  /*   margin: 0 20px; */
  width: 100%;
  height: 100%;
}



</style>



